import React from "react";
import '../CSS/myStyles.css';

// create a function component for the filter block to be displayed in the category ribbon 
const FilterBlock = () => {
    return (
        <div id="filter-container">
            <div id="filter-block">Filters</div>
        </div>
    )
}

export default FilterBlock;