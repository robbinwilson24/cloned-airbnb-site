import React from "react";
import { Card, Image, Container, Row, Badge, Col } from "react-bootstrap";
import "../CSS/myStyles.css";

// assign properties to an array with all the required details to be displayed on the main webpage.
const PropertiesArray = [
 { location: "London, England", hostType: "Professional Host", dates: "17-21 Apr", totalPrice: "£890", rating: "★4.72", propertyImg: "https://images.pexels.com/photos/4482667/pexels-photo-4482667.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" },
 { location: "Amsterdam, Netherlands" , hostType: "Professional Host", dates: "17-21 Apr", totalPrice:"£740", rating:"★4.87", propertyImg: "https://images.pexels.com/photos/5178100/pexels-photo-5178100.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Edinburgh, Scotland" , hostType: "Individual Host", dates: "17-21 Apr", totalPrice:"£810", rating:"★4.77", propertyImg: "https://images.pexels.com/photos/14343605/pexels-photo-14343605.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Barcelona, Spain", hostType: "Professional Host", dates: "20-24 Apr", totalPrice: "£790", rating: "★4.67", propertyImg: "https://images.pexels.com/photos/2379980/pexels-photo-2379980.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Paris, France" , hostType: "Individual Host", dates: "20-24 Apr", totalPrice:"£820", rating:"★4.89", propertyImg: "https://images.pexels.com/photos/952587/pexels-photo-952587.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Berlin, Germany" , hostType: "Professional Host", dates: "20-24 Apr", totalPrice:"£760", rating:"★4.82", propertyImg: "https://images.pexels.com/photos/4547586/pexels-photo-4547586.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Edinburgh, Scotland" , hostType: "Individual Host", dates: "17-21 Apr", totalPrice:"320", rating:"★3.98", propertyImg: "https://images.pexels.com/photos/12233830/pexels-photo-12233830.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Rome, Italy", hostType: "Individual Host", dates: "22-26 Apr", totalPrice: "£830", rating: "★4.70", propertyImg: "https://images.pexels.com/photos/3038552/pexels-photo-3038552.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Vienna, Austria" , hostType: "Professional Host", dates: "22-26 Apr", totalPrice:"£820", rating:"★4.87", propertyImg: "https://images.pexels.com/photos/208360/pexels-photo-208360.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Prague, Czech Republic" , hostType: "Individual Host", dates: "22-26 Apr", totalPrice:"£810", rating:"★4.79", propertyImg: "https://images.pexels.com/photos/323311/pexels-photo-323311.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Budapest, Hungary", hostType: "Professional Host", dates: "24-28 Apr", totalPrice: "£770", rating: "★4.68", propertyImg: "https://images.pexels.com/photos/4906403/pexels-photo-4906403.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "London, England", hostType: "Individual Host", dates: "17-21 Apr", totalPrice: "£490", rating: "★4.12", propertyImg: "https://images.pexels.com/photos/2214035/pexels-photo-2214035.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Dublin, Ireland" , hostType: "Individual Host", dates: "24-28 Apr", totalPrice:"£840", rating:"★4.91", propertyImg: "https://images.pexels.com/photos/1208781/pexels-photo-1208781.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Brussels, Belgium" , hostType: "Professional Host", dates: "24-28 Apr", totalPrice:"£750", rating:"★4.83", propertyImg: "https://images.pexels.com/photos/2587789/pexels-photo-2587789.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Oslo, Norway", hostType: "Individual Host", dates: "26-30 Apr", totalPrice: "£870", rating: "★4.71", propertyImg: "https://images.pexels.com/photos/2360668/pexels-photo-2360668.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Stockholm, Sweden" , hostType: "Professional Host", dates: "26-30 Apr", totalPrice:"£830", rating:"★4.88", propertyImg: "https://images.pexels.com/photos/2377432/pexels-photo-2377432.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Copenhagen, Denmark" , hostType: "Individual Host", dates: "26-30 Apr", totalPrice:"£820", rating:"★4.80", propertyImg: "https://images.pexels.com/photos/416024/pexels-photo-416024.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Amsterdam, Netherlands" , hostType: "Individual Host", dates: "17-21 Apr", totalPrice:"£495", rating:"★4.01", propertyImg: "https://images.pexels.com/photos/1187911/pexels-photo-1187911.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Nottingham, England" , hostType: "Individual Host", dates: "17-21 Apr", totalPrice:"£380", rating:"★4.61", propertyImg: "https://images.pexels.com/photos/7511456/pexels-photo-7511456.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Manchester, England", hostType: "Professional Host", dates: "24-28 Apr", totalPrice: "£450", rating: "★4.82", propertyImg: "https://images.pexels.com/photos/2607731/pexels-photo-2607731.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "London, England", hostType: "Professional Host", dates: "01-05 May", totalPrice: "£600", rating: "★4.96", propertyImg: "https://images.pexels.com/photos/2887920/pexels-photo-2887920.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Birmingham, England", hostType: "Individual Host", dates: "08-12 May", totalPrice: "£320", rating: "★4.71", propertyImg: "https://images.pexels.com/photos/7244471/pexels-photo-7244471.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Liverpool, England", hostType: "Individual Host", dates: "15-19 May", totalPrice: "£400", rating: "★4.89", propertyImg: "https://images.pexels.com/photos/7568261/pexels-photo-7568261.jpeg?auto=compress&cs=tinysrgb&w=600" },
 { location: "Bristol, England", hostType: "Professional Host", dates: "22-26 May", totalPrice: "£500", rating: "★4.93", propertyImg: "https://images.pexels.com/photos/6184882/pexels-photo-6184882.jpeg?auto=compress&cs=tinysrgb&w=600" }

]

 // Create a function component that takes the props of the properties in the above array to populate the cards displayed on the webpage. 
 // Use Card and relative card components from react-bootstrap  
function PropertyCard(props) {
    return(
            <Card  className="property-card">
                <Image className="property-image" src={props.propertyImg} alt={props.location} />
                <Card.Body>
                    <Row>
                        <Col className="card-info-top">
                            <Card.Title className="property-location">{props.location}</Card.Title>
                            <Badge className="rating">{props.rating}</Badge>
                        </Col>
                    </Row>
                    <Card.Text className="host-and-date">
                        {props.hostType}
                        <br/>
                        {props.dates}
                    </Card.Text>
                    <Card.Text className="total-price"><span className="price-value">{props.totalPrice}</span> total</Card.Text>
                </Card.Body>
            </Card>
    )
}

// Map the array and output a property card for each array item . 
function MapProperty() {
    return(
        PropertiesArray.map((property, index) => (
            <PropertyCard
                key={index}
                location={property.location}
                hostType={property.hostType}
                dates={property.dates}
                totalPrice={property.totalPrice}
                rating={property.rating}
                propertyImg={property.propertyImg}
            />
        )))
}


// create a function to render and output the displayed properties to the App.js file 
function RenderProperties() {
    return(
        <div className="property-card-container">
            {MapProperty()}
        </div>
    )
}

export default RenderProperties; 
