import React from "react";
import '../CSS/myStyles.css';

// Create a function to generate the page footer with all the relevant info 
function Footer() {
  return (
    <div className="footer">
        <div className="left-links">
            <div className="footer-links">
                {/* // add the footer links that will be displayed on the left of the footer, link the real world URLs where possible */}
                <p>© 2023</p><p>•</p>
                <p><a className="footer-a-tag"  href="https://www.airbnb.co.uk/help/article/2855">Privacy</a> </p><p>•</p>
                <p><a className="footer-a-tag"  href="https://www.airbnb.co.uk/help/article/2908">Terms</a> </p><p>•</p>
                <p><a className="footer-a-tag"  href="https://www.airbnb.co.uk/sitemaps/v2">Sitemap</a></p><p>•</p>
                <p><a className="footer-a-tag"  href="https://a0.muscache.com/static/uk-modern-slavery-act-statement.pdf">UK Modern Slavery Act</a> </p><p>•</p>
                <p><a className="footer-a-tag"  href="https://www.airbnb.co.uk/about/company-details">Company Details</a></p><p>•</p>
                <p><a className="footer-a-tag"  href="https://www.airbnb.co.uk/">REAL WEBSITE LINK</a></p>
            </div>
        </div>

        <div className="right-links">
            {/* // Add footer links to be displayed on the right of the footer */}
            <p className="right-link">🌐Engish (GB)  </p>
            <p className="right-link">£ GBP  </p>
            <p className="right-link">Support & resources  </p>
        </div>
    </div>
  );
};

export default Footer;