import React from "react";
import '../CSS/myStyles.css';

// import the image icons that are used in the category section of the webpage 
import UFO from "../Icons/ufo.png";
import View from "../Icons/views.png";
import Beach from "../Icons/beach.png";
import Countryside from "../Icons/countryside.png";
import Tea from "../Icons/tea.png";
import Mansion from "../Icons/mansion.png";
import Lux from "../Icons/lux.png";
import Hut from "../Icons/hut.png";
import Cabin from "../Icons/cabin.png";
import Boat from "../Icons/boat.png";
import Barn from "../Icons/barn.png";
import Hot from "../Icons/hot.png";
import Pool from "../Icons/pool.png";
import Ski from "../Icons/ski.png";
import Castle from "../Icons/castle.png";
import Room from "../Icons/room.png";
import Tree from "../Icons/tree.png";
import Grapes from "../Icons/grapes.png";
import Snow from "../Icons/snowflake.png";
import Cave from "../Icons/cave.png";
import Tent from "../Icons/tent.png";


// put all category types into an array containing their icon and name . 
const categoryArray = [
    {name: "OMG!", icon:UFO },
    {name: "Amazing Views", icon: View },
    {name: "Beachfront", icon: Beach },
    {name: "Countryside", icon: Countryside },
    {name: "Bed & Breakfasts", icon: Tea },
    {name: "Mansions", icon: Mansion },
    {name: "Luxe", icon: Lux },
    {name: "Shepherd's Hut", icon: Hut },
    {name: "Cabins", icon: Cabin },
    {name: "Ski-in/out", icon: Ski  },
    {name: "Boats", icon: Boat },
    {name: "Barns", icon: Barn },
    {name: "Trending", icon: Hot },
    {name: "Amazing Pools", icon: Pool },
    {name: "Castles", icon: Castle },
    {name: "Private Rooms", icon: Room  },
    {name: "Treehouses", icon: Tree },
    {name: "Vinyards", icon: Grapes },
    {name: "Arctic", icon: Snow },
    {name: "Caves", icon: Cave },
    {name: "Camping", icon: Tent },
];

// Map the array to output the icons to the main page. 
 function CategoryBar(props) {
    return(
        <div className='property-category'>
            <img className="category-icon" src={props.icon} alt={props.name + " icon"}/>
            <p className='category-name'>{props.name}</p>
        </div>
    )
 }

 function MapCategories() {
    return(
        categoryArray.map((category, index) => (
            <CategoryBar key={index} icon={category.icon} name={category.name}
            />
        ))        
    )
 }
 export default MapCategories;
