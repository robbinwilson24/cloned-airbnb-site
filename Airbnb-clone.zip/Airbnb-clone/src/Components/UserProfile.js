import React, { useState, useRef, useEffect } from "react";
import '../CSS/myStyles.css';
import Profile from "../Icons/profile.png";
import Menu from "../Icons/menu.png"; 

// create a function that will create a drop down user profile menue when the profile icon is clicked 

function UserMenu() {
    // use state to set the menu as hidden , and have the state change when the menu is clicked
    const [dropdownOpen, setDropdownOpen] = useState(false);
    const dropdownRef = useRef(null);
  
    // create functions to handle the click events and use the useEffect react hook , to show the menu and to hide it when the user clicks off it 
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    }
    // useEffect hook to listen for when the mouse is clicked 
    useEffect(() => {
      document.addEventListener("mousedown", handleClickOutside);
      return () => {
        document.removeEventListener("mousedown", handleClickOutside);
      };
    });
    
    // create a function to toggle the menu's visibility 
    function toggleDropdown() {
      setDropdownOpen(!dropdownOpen);
    }
  
    // return the menu to be rendered 
    return (
      <nav>
        <div className="menu-container">
          <div id="user-profile" className="nav-item" onClick={toggleDropdown}>
              <img id="menu-icon" src={Menu}/>
              <img id="profile-icon" src={Profile}/>
          </div>
          {dropdownOpen && (
            <ul ref={dropdownRef} className="dropdown">
              <li className="dropdown-item">Log In</li>
              <li className="dropdown-item">Sign Up</li>
              <li className="dropdown-item">List Your Home</li>
              <li className="dropdown-item">Host an Experience</li>
              <li className="dropdown-item">Help</li>
            </ul>
          )}
        </div>
      </nav>
    );
  }
  
  export default UserMenu;

