import React from 'react';
import '../CSS/myStyles.css';
import MainLogo from "../Icons/main-logo-red.png";
import MainTitle from "../Icons/Airbnb_Logo.png";
import Search from "../Icons/search.png";
import Globe from "../Icons/globe.png";

// import the use menu component 
import UserMenu from './UserProfile';

// create a function that will render the main menu ribbon at the top of the page 
function MenuRibbon() {
    return (
        // add a div for the logo and title to be displayed on the left of the page
      <div className="main-ribbon">
        <div className="ribbon-logo-section">
            <img id="main-ribbon-logo" src={MainLogo} alt="Main Logo"/>
            <img id="main-ribbon-title" src={MainTitle} alt="Airbnb Title"/>
        </div>
        
        {/* add a div for the search bar that will be displayed in the middle of the screen */}
        <div className='search-menu'>
            <div className='search-menu-item'>Anywhere </div>
            <div className='search-menu-item'>Any week</div>
            <div className='add-guest-item'>Add guests</div>
            <div>
                <img id="search-icon" src={Search}/>
            </div>
        </div>
  
        {/* add a div for the section that will be displayed on the right of the screen */}
        <div className="right-header-section">
                <div  id="your-home">Airbnb your home</div>
                <div>
                    <img id="globe-icon" src={Globe}/>
                </div>
                <div id="user-profile-container">
                    {/* Add the user menu component to be rendered */}
                    <UserMenu/>
                </div>
  
        </div>
      </div>
    );
  }
  
  export default MenuRibbon;


