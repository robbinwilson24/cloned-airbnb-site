import logo from './logo.svg';
import MenuRibbon from './Components/MenuRibbon';
import RenderProperties from './Components/PropertyCards';
import MapCategories from './Components/CategoryRibbon';
import Footer from './Components/Footer';
import FilterBlock from './Components/FilterBlock';


function App() {
  return (
    <div className="App">
      <MenuRibbon/>
         <div id="category-container">
            {MapCategories()}
            <FilterBlock/>
         </div>      
      <RenderProperties/>
      <Footer/>
    </div>
  );
}

export default App;


